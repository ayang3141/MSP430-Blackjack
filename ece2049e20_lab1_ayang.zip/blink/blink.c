//***************************************************************************************
//  MSP430 Blink the LED Demo - Software Toggle P1.0
//
//  Description; Toggle P1.0 by xor'ing P1.0 inside of a software loop.
//  ACLK = n/a, MCLK = SMCLK = default DCO
//
//                MSP430x5xx
//             -----------------
//         /|\|              XIN|-
//          | |                 |
//          --|RST          XOUT|-
//            |                 |
//            |             P1.0|-->LED
//
//  J. Stevenson
//  Texas Instruments, Inc
//  July 2011
//  Built with Code Composer Studio v5
//***************************************************************************************


#include <msp430.h>
#include <string.h>

// Function prototype
void swDelay(void);

int main(void) {
    WDTCTL = WDTPW | WDTHOLD;       // Stop watchdog timer


    // Set digital IO control registers for  Port 1 Pin 0
    P1SEL = P1SEL & ~BIT0;          // Select P1.0 for digital IO
    P1DIR |= BIT0;                  // Set P1.0 to output direction
    __disable_interrupt();          // Not using interrupts so disable them

    while(1)   // forever loop
    {
        P1OUT = P1OUT ^ BIT0;       // Toggle P1.0 using exclusive-OR

        // Comment the above line and uncomment ONE of these at a time
        // to test which logic level lights the LED
        //P1OUT = P1OUT & ~BIT0;    // Set bit 0 of P1OUT to zero
        //P1OUT |= BIT0;            // Set bit 0 of P1OUT to one

        swDelay();
    }
}


// This function creates a delay in software.
void swDelay(void)
{
    volatile unsigned int i;    // volatile to prevent optimization
                                // by compiler

    i = 50000;
    while (i != 0)    // could have used while (i)
       i--;
}
