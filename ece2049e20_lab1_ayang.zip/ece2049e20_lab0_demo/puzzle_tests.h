/*
 * lab0_tests.h
 *
 *  Created on: Apr 19, 2018
 *      Author: deemer
 */

#ifndef PUZZLE_TESTS_H_
#define PUZZLE_TESTS_H_

#include "utils/debug_assert.h"

// Run all puzzle tests
void test_all_puzzles(void);




#endif /* PUZZLE_TESTS_H_ */
