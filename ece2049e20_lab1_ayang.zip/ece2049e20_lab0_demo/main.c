/************** ECE2049 DEMO CODE ******************/
/************** 14 May 2018   **********************/
/***************************************************/

#include <msp430.h>
#include <puzzle_tests.h>

/* Peripherals.c and .h are where the functions that implement
 * the LEDs and keypad, etc are. It is often useful to organize
 * your code by putting like functions together in files.
 * You include the header associated with that file(s)
 * into the main file of your project. */
#include "peripherals.h"

// Include puzzles for lab 0

// Function Prototypes
void swDelay(char numLoops);

// Declare globals here

// Main
void main(void)
{
    // Define some local variables
    float a_flt = 190.68;
    int  test = 0x0800;      // In C prefix 0x means the number that follows is in hex
    long unsigned X = 114656;     // No prefix so number is assumed to be in decimal
    unsigned char myGrade='A';

    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                 // You can then configure it properly, if desired

    // Some utterly useless instructions
    // Use the debugger to step through these instructions.
    //
    // Q: What size does the Code Composer MSP430 Compiler use for the
    // following variable types:  float, an int, a long integer and char?
    // Answer: float = 32-bit; int = 16-bit; long = 32-bit; char = 8-bit
    a_flt = a_flt * test;
    X = test + X;
    test = test - myGrade;    // Q: A number minus a letter?? What's actually going on here?
                              // What value stored in myGrade (i.e. what's the ASCII code for "A")?
                                // Answer: 65

    // Step past this point in the debugger
    // Q: What is the new value for test?  Explain the result.
    // Answer: the value for test is 1983 because even though we technically cannot subtract a letter from a number,
    // the code compiler uses the ASCII code for A, which IS a integer. Initially, test starts off as 0x0800 (which is hexidecimal for 2048).
    // When the compiler sees the command "test = test - myGrade", the compiler uses the ASCII code for A (which is 65).
    // Therefore, the compiler ultimately assigns test = 2048 - 65 = 1983.


    // *** System initialization ***
    initLaunchpadButtons();
    initLaunchpadLeds();
    configDisplay();

    // ******* PUZZLES *********
    // Run tests on programming puzzles for lab 0
    // Ctrl+Click on this function to find its source
    test_all_puzzles();

    // Make some noise to indicate we're done with puzzles
    // (This will do nothing unless you are using a board with an external buzzer)
    BuzzerOn();
    swDelay(1);
    BuzzerOff();

    // ********* DEMO CODE **********
    // This part of the program demonstrates an actual
    // program that provides some useful functionality with the hardware

    // *** Intro Screen ***

    Graphics_clearDisplay(&g_sContext); // Clear the display

    // Write some text to the display
    int h_center = LCD_HORIZONTAL_MAX / 2;

    // LCD_HORIZONTAL_MAX = 128;


    // 15,25,35 numbers control vertical positioning of the text (15 is near top, 35 is near bottom)
    //h_center input controls the horizontal positioning of the text (0 is far left, 128 is far right)
    Graphics_drawStringCentered(&g_sContext, "Welcome",  AUTO_STRING_LENGTH, h_center, 15, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, "to",       AUTO_STRING_LENGTH, h_center, 25, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, "ECE2049!", AUTO_STRING_LENGTH, h_center, 35, TRANSPARENT_TEXT);

    // Draw a box around everything because it looks nice
    Graphics_Rectangle box = {.xMin = 5, .xMax = LCD_HORIZONTAL_MAX - 5,
                              .yMin = 5, .yMax = LCD_VERTICAL_MAX - 5 };
    Graphics_drawRectangle(&g_sContext, &box);

    // We are now done writing to the display.  However, if we stopped here, we would not
    // see any changes on the actual LCD.  This is because we need to send our changes
    // to the LCD, which then refreshes the display.
    // Since this is a slow operation, it is best to refresh (or "flush") only after
    // we are done drawing everything we need.
    Graphics_flushBuffer(&g_sContext);


    // In our loop, we are going to read from the buttons and use that input
    // to update the LCD display.
    // To draw text on the display, we need to build an array of characters, so
    // here we make a "buffer" of 3 characters that we will adjust based on our input
    unsigned char buffer[3];
    buffer[0] = '>';
    buffer[2] = '<';

    while (1)    // Forever loop
    {
        // Q: How does what you press on the launchpad buttons change the value of button_state?
        // Answer: depending on the configuration of the buttons pressed,
        // the readLanuchpadButtons function returns an 8-bit hexadecimal number, which the compiler interprets as a character
        // the variable button_state is then set to this 8-bit hexadecimal number.

        char button_state = readLaunchpadButtons();

        if (button_state != 0)
        {
            setLaunchpadLeds(button_state);

            // Update the buffer based on the button state
            // Q: What does the "+ '0'" do?  Why is it necessary?

            // Answer: note that the ASCII code for '0' is 48.
            // right button_state has value 1 when pressed; thus, buffer[1] has value 49
            // left button_state has value 2 when pressed; thus, buffer[1] has value 50

            // notice that the ASCII codes for 1 and 2 (which also appear on the LCD screen
            // when you pressed the respective buttons) are 49 and 50 respectively
            // Therefore, the " + '0'" essentially adds the value 48 to the value of the button_state
            // It is necessary because without the '0' added in, the value of buffer[1] would NOT reach the appropriate ASCII codes of 1 and 2.
            // In other words, if '0' was not there, something else other than 1 or 2 would be displayed on the LCD screen.

            // (What happens if you remove the "+ '0'"?)
            // Hint:  think back to the earlier question about the new value for "test".
            buffer[1] = button_state + '0';

            // Draw the characters in our buffer.  Our buffer is always 3 characters long,
            // so we can specify a length of 3 rather than using AUTO_STRING_LENGTH for argument 3
            Graphics_drawStringCentered(&g_sContext, buffer,  3, h_center, 45, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext); // Update the display
        }

    }  // end while (1)
}


void swDelay(char numLoops)
{
	// This function is a software delay. It performs
	// useless loops to waste a bit of time
	//
	// Input: numLoops = number of delay loops to execute
	// Output: none
	//
	// smj, ECE2049, 25 Aug 2013

	volatile unsigned int i,j;	// volatile to prevent removal in optimization
			                    // by compiler. Functionally this is useless code

	for (j=0; j<numLoops; j++)
    {
    	i = 50000 ;					// SW Delay
   	    while (i > 0)				// could also have used while (i)
	       i--;
    }
}
